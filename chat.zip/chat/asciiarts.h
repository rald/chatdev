#ifndef ASCIIARTS__H
#define ASCIIARTS__H
char* getAsciiText(char *loc);
void printAsciiText(WINDOW *window,char *filename, int y, int x, int cpair_id);
#endif
