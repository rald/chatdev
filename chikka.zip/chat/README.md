# ChatServer

![ChatServerClient](https://user-images.githubusercontent.com/51853225/117621337-cd606700-b171-11eb-84bd-b4e6fe5d19d6.jpg)
---RUN---:


To run program:
- make
- ./server port
- ./client hostadress port 

---HELP---:

If there are appearing any weird character in the client gui, or it is flickering,try to do this:
- export NCURSES_NO_UTF8_ACS=1
if you are in a bash like shell or in csh like shell:
- setenv NCURSES_NO_UTF8_ACS 1

made by Markus Telser<br>
10.05.2021, Bolzano
